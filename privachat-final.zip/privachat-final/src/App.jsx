import { useState, useEffect, useRef, useCallback } from "react";

// ─── Constants ───
const PUB_KEY="demo",SUB_KEY="demo",CH_BASE="claudechat_v6_";
const uid=()=>Math.random().toString(36).slice(2,10);
const roomCode=()=>Math.random().toString(36).slice(2,8).toUpperCase();
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const myUUID=uid();
const PALETTE=["#2AABEE","#FF6B6B","#51CF66","#FF922B","#CC5DE8","#20C997","#FCC419","#F783AC"];
const getColor=n=>{let h=0;for(const c of n)h=(h*31+c.charCodeAt(0))&0xFFFF;return PALETTE[h%PALETTE.length];};
const EMOJIS=["❤️","👍","😂","😮","😢","🔥"];
const SD_OPTS=[{l:"10s",v:10},{l:"30s",v:30},{l:"1 min",v:60},{l:"5 min",v:300}];
const LOCK_OPTS=[{l:"1 min",v:60},{l:"5 min",v:300},{l:"15 min",v:900},{l:"30 min",v:1800}];
const getCh=(id,pwd)=>{if(!pwd)return CH_BASE+id;let h=5381;for(const c of pwd)h=((h<<5)+h)^c.charCodeAt(0);return CH_BASE+id+"_"+Math.abs(h).toString(36);};

const COUNTRIES=[
  {code:"ar",name:"Argentina",flag:"🇦🇷",lang:"es",langName:"Español"},
  {code:"mx",name:"México",flag:"🇲🇽",lang:"es",langName:"Español"},
  {code:"co",name:"Colombia",flag:"🇨🇴",lang:"es",langName:"Español"},
  {code:"cl",name:"Chile",flag:"🇨🇱",lang:"es",langName:"Español"},
  {code:"es",name:"España",flag:"🇪🇸",lang:"es",langName:"Español"},
  {code:"pe",name:"Perú",flag:"🇵🇪",lang:"es",langName:"Español"},
  {code:"uy",name:"Uruguay",flag:"🇺🇾",lang:"es",langName:"Español"},
  {code:"us",name:"USA",flag:"🇺🇸",lang:"en",langName:"English"},
  {code:"gb",name:"UK",flag:"🇬🇧",lang:"en",langName:"English"},
  {code:"ca",name:"Canada",flag:"🇨🇦",lang:"en",langName:"English"},
  {code:"br",name:"Brasil",flag:"🇧🇷",lang:"pt",langName:"Português"},
  {code:"pt",name:"Portugal",flag:"🇵🇹",lang:"pt",langName:"Português"},
  {code:"fr",name:"Francia",flag:"🇫🇷",lang:"fr",langName:"Français"},
  {code:"de",name:"Alemania",flag:"🇩🇪",lang:"de",langName:"Deutsch"},
  {code:"it",name:"Italia",flag:"🇮🇹",lang:"it",langName:"Italiano"},
  {code:"ru",name:"Rusia",flag:"🇷🇺",lang:"ru",langName:"Русский"},
  {code:"cn",name:"China",flag:"🇨🇳",lang:"zh",langName:"中文"},
  {code:"jp",name:"Japón",flag:"🇯🇵",lang:"ja",langName:"日本語"},
  {code:"kr",name:"Corea",flag:"🇰🇷",lang:"ko",langName:"한국어"},
  {code:"tr",name:"Turquía",flag:"🇹🇷",lang:"tr",langName:"Türkçe"},
  {code:"sa",name:"Arabia",flag:"🇸🇦",lang:"ar",langName:"العربية"},
  {code:"nl",name:"Holanda",flag:"🇳🇱",lang:"nl",langName:"Nederlands"},
  {code:"se",name:"Suecia",flag:"🇸🇪",lang:"sv",langName:"Svenska"},
  {code:"pl",name:"Polonia",flag:"🇵🇱",lang:"pl",langName:"Polski"},
  {code:"id",name:"Indonesia",flag:"🇮🇩",lang:"id",langName:"Bahasa"},
];

// ─── Crypto (AES-256-GCM) ───
const deriveKey=async(pwd,roomId)=>{
  const enc=new TextEncoder();
  const km=await crypto.subtle.importKey("raw",enc.encode(pwd+roomId),{name:"PBKDF2"},false,["deriveKey"]);
  return crypto.subtle.deriveKey({name:"PBKDF2",salt:enc.encode("privachat-v1-salt"),iterations:100000,hash:"SHA-256"},km,{name:"AES-GCM",length:256},false,["encrypt","decrypt"]);
};
const encryptText=async(key,plain)=>{
  const iv=crypto.getRandomValues(new Uint8Array(12));
  const buf=await crypto.subtle.encrypt({name:"AES-GCM",iv},key,new TextEncoder().encode(plain));
  const combined=new Uint8Array(12+buf.byteLength);combined.set(iv);combined.set(new Uint8Array(buf),12);
  return btoa(String.fromCharCode(...combined));
};
const decryptText=async(key,cipher)=>{
  try{const b=Uint8Array.from(atob(cipher),c=>c.charCodeAt(0));const iv=b.slice(0,12);const data=b.slice(12);const dec=await crypto.subtle.decrypt({name:"AES-GCM",iv},key,data);return new TextDecoder().decode(dec);}
  catch{return null;}
};

// ─── Utilities ───
const playNotif=()=>{try{const ctx=new(window.AudioContext||window.webkitAudioContext)();const o=ctx.createOscillator(),g=ctx.createGain();o.connect(g);g.connect(ctx.destination);o.frequency.value=880;o.type="sine";g.gain.setValueAtTime(0.12,ctx.currentTime);g.gain.exponentialRampToValueAtTime(0.001,ctx.currentTime+0.22);o.start();o.stop(ctx.currentTime+0.22);}catch{}};
const playAlert=()=>{try{const ctx=new(window.AudioContext||window.webkitAudioContext)();const o=ctx.createOscillator(),g=ctx.createGain();o.connect(g);g.connect(ctx.destination);o.frequency.value=440;o.type="square";g.gain.setValueAtTime(0.08,ctx.currentTime);g.gain.exponentialRampToValueAtTime(0.001,ctx.currentTime+0.4);o.start();o.stop(ctx.currentTime+0.4);}catch{}};

const compressImg=file=>new Promise((res,rej)=>{const r=new FileReader();r.onload=e=>{const img=new Image();img.onload=()=>{let[w,h,M]=[img.width,img.height,300];if(w>M||h>M){if(w>h){h=Math.round(h*M/w);w=M;}else{w=Math.round(w*M/h);h=M;}}const cv=document.createElement("canvas");cv.width=w;cv.height=h;cv.getContext("2d").drawImage(img,0,0,w,h);let q=0.6,d=cv.toDataURL("image/jpeg",q);while(d.length>26000&&q>0.2){q-=0.1;d=cv.toDataURL("image/jpeg",q);}d.length>30000?rej(new Error("too_large")):res(d);};img.onerror=rej;img.src=e.target.result;};r.onerror=rej;r.readAsDataURL(file);});

const callClaude=async p=>{const r=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:500,messages:[{role:"user",content:p}]})});const d=await r.json();return d.content?.[0]?.text?.trim()||"";};

const checkVPN=async()=>{
  try{const r=await fetch("https://ip-api.com/json/?fields=status,country,countryCode,proxy,hosting,query",{signal:AbortSignal.timeout(4000)});const d=await r.json();return{isVPN:d.proxy||d.hosting,country:d.country,countryCode:d.countryCode,ip:d.query,type:d.proxy?"Proxy/VPN":d.hosting?"Hosting/Datacenter":""};}
  catch{return{isVPN:false};}
};

// ─── Sub-components ───
const Avatar=({name,size=36,ring=false})=>(<div style={{width:size,height:size,borderRadius:"50%",background:getColor(name),flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center",fontSize:size*.38,fontWeight:700,color:"#fff",fontFamily:"'Outfit',sans-serif",boxShadow:ring?`0 0 0 2px #161b22,0 0 0 3.5px ${getColor(name)}`:"none"}}>{name.split(" ").map(w=>w[0]).join("").slice(0,2).toUpperCase()}</div>);

function CountDown({duration,onEnd}){const[l,setL]=useState(duration);useEffect(()=>{const t=setInterval(()=>setL(v=>{if(v<=1){clearInterval(t);onEnd();return 0;}return v-1;}),1000);return()=>clearInterval(t);},[]);const p=l/duration;const col=p>.5?"#3fb950":p>.25?"#e3b341":"#f85149";return<span style={{fontSize:11,color:col,display:"flex",alignItems:"center",gap:3,fontWeight:600}}>💨{l}s</span>;}

function AudioPlayer({src,duration:dur}){const[playing,setP]=useState(false);const[prog,setPr]=useState(0);const[len,setL]=useState(dur||0);const aRef=useRef(null);const toggle=()=>{if(playing){aRef.current.pause();setP(false);}else{aRef.current.play();setP(true);}};const fmt=s=>`${Math.floor(s/60)}:${String(Math.floor(s%60)).padStart(2,"0")}`;return(<div style={{display:"flex",alignItems:"center",gap:8,minWidth:190,padding:"4px 0"}}><audio ref={aRef} src={src} onTimeUpdate={e=>setPr(e.target.currentTime/e.target.duration*100)} onLoadedMetadata={e=>setL(e.target.duration)} onEnded={()=>{setP(false);setPr(0);}}/><button onClick={toggle} style={{width:34,height:34,borderRadius:"50%",background:"#2AABEE",border:"none",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,fontSize:14}}>{playing?"⏸":"▶️"}</button><div style={{flex:1}}><div style={{height:3,background:"#2a3f52",borderRadius:2,overflow:"hidden",cursor:"pointer"}} onClick={e=>{const r=e.currentTarget.getBoundingClientRect();if(aRef.current)aRef.current.currentTime=(e.clientX-r.left)/r.width*aRef.current.duration;}}><div style={{width:`${prog}%`,height:"100%",background:"#2AABEE",transition:"width .1s"}}/></div><div style={{fontSize:10,color:"#7d8590",marginTop:2}}>🎤 {fmt(len)}</div></div></div>);}

function PollCard({msg,myName,onVote}){const total=msg.options.reduce((s,o)=>s+o.votes.length,0);const myVote=msg.options.findIndex(o=>o.votes.includes(myName));return(<div style={{minWidth:200}}><div style={{fontSize:13,fontWeight:700,marginBottom:10}}>📊 {msg.question}</div>{msg.options.map((opt,i)=>{const pct=total>0?Math.round(opt.votes.length/total*100):0;const voted=myVote===i;return(<button key={i} onClick={()=>onVote(msg.id,i)} style={{display:"block",width:"100%",marginBottom:6,background:voted?"rgba(42,171,238,.18)":"#1c2c3a",border:`1.5px solid ${voted?"#2AABEE":"#21293a"}`,borderRadius:8,padding:"7px 10px",cursor:"pointer",textAlign:"left",position:"relative",overflow:"hidden",transition:"all .2s"}}><div style={{position:"absolute",top:0,left:0,height:"100%",width:`${pct}%`,background:"rgba(42,171,238,.1)",transition:"width .4s",borderRadius:8}}/><div style={{position:"relative",display:"flex",justifyContent:"space-between",fontSize:13,color:"#e6edf3"}}><span>{voted?"✓ ":""}{opt.text}</span><span style={{color:"#7d8590",fontSize:12}}>{pct}%</span></div></button>);})}<div style={{fontSize:11,color:"#7d8590",marginTop:4}}>{total} {total===1?"voto":"votos"}</div></div>);}

// ─── PIN Lock Overlay ───
function PinLock({onUnlock,attempts}){
  const[digits,setDigits]=useState([]);
  const[shake,setShake]=useState(false);
  const add=d=>{if(digits.length>=4)return;const n=[...digits,d];setDigits(n);if(n.length===4){const ok=onUnlock(n.join(""));if(!ok){setShake(true);setTimeout(()=>{setDigits([]);setShake(false);},600);}}};
  const del=()=>setDigits(p=>p.slice(0,-1));
  return(<div style={{position:"fixed",inset:0,zIndex:9000,background:"#0d1117",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:24}}>
    <div style={{fontSize:48}}>🔒</div>
    <div style={{fontWeight:700,fontSize:20}}>Sala bloqueada</div>
    <div style={{fontSize:13,color:"#7d8590"}}>Ingresá tu PIN para continuar</div>
    {attempts>0&&<div style={{fontSize:12,color:"#f85149"}}>PIN incorrecto — intento {attempts}</div>}
    <div style={{display:"flex",gap:14,margin:"8px 0",animation:shake?"shake .5s ease":"none"}}>
      {[0,1,2,3].map(i=>(<div key={i} style={{width:18,height:18,borderRadius:"50%",background:i<digits.length?"#2AABEE":"#21293a",border:"2px solid",borderColor:i<digits.length?"#2AABEE":"#30363d",transition:"all .15s"}}/>))}
    </div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12}}>
      {[1,2,3,4,5,6,7,8,9].map(n=>(<button key={n} onClick={()=>add(String(n))} style={{width:70,height:70,borderRadius:16,background:"#161b22",border:"1px solid #21293a",color:"#e6edf3",fontSize:22,fontWeight:600,cursor:"pointer",fontFamily:"'Outfit',sans-serif",transition:"all .15s",boxShadow:"0 2px 8px rgba(0,0,0,.3)"}}>{n}</button>))}
      <div/>
      <button onClick={()=>add("0")} style={{width:70,height:70,borderRadius:16,background:"#161b22",border:"1px solid #21293a",color:"#e6edf3",fontSize:22,fontWeight:600,cursor:"pointer",fontFamily:"'Outfit',sans-serif",transition:"all .15s"}}>0</button>
      <button onClick={del} style={{width:70,height:70,borderRadius:16,background:"#161b22",border:"1px solid #21293a",color:"#7d8590",fontSize:20,cursor:"pointer",fontFamily:"'Outfit',sans-serif"}}>⌫</button>
    </div>
    <style>{`@keyframes shake{0%,100%{transform:translateX(0)}25%{transform:translateX(-8px)}75%{transform:translateX(8px)}}`}</style>
  </div>);
}

// ─── Join Toast ───
function JoinToast({user,flag,country,onDone}){
  useEffect(()=>{const t=setTimeout(onDone,4000);return()=>clearTimeout(t);},[]);
  return(<div style={{position:"fixed",top:16,left:"50%",transform:"translateX(-50%)",zIndex:8000,background:"#161b22",border:"1px solid #21293a",borderRadius:16,padding:"12px 20px",display:"flex",alignItems:"center",gap:12,boxShadow:"0 8px 32px rgba(0,0,0,.5)",animation:"slideDown .3s ease",minWidth:240}}>
    <Avatar name={user} size={36} ring/>
    <div>
      <div style={{fontWeight:600,fontSize:14}}>{flag} {user} se unió</div>
      <div style={{fontSize:12,color:"#7d8590"}}>desde {country||"desconocido"} 🔔</div>
    </div>
  </div>);
}

// ─── Watermark ───
function Watermark({name}){return(<div style={{position:"fixed",inset:0,pointerEvents:"none",zIndex:800,overflow:"hidden",userSelect:"none"}}>{Array.from({length:16}).map((_,i)=>(<div key={i} style={{position:"absolute",left:"-20%",right:"-20%",top:`${i*90-10}px`,transform:"rotate(-22deg)",display:"flex",gap:60,whiteSpace:"nowrap",fontSize:13,fontWeight:700,letterSpacing:2,color:"rgba(200,220,255,0.05)",fontFamily:"'Outfit',sans-serif"}}>{Array.from({length:6}).map((_,j)=>(<span key={j}>{name.toUpperCase()} · PRIVADO · {new Date().toLocaleDateString("es")}</span>))}</div>))}</div>);}

// ─── Screenshot Alert ───
function AlertOverlay({name,onDone}){useEffect(()=>{const t=setTimeout(onDone,3000);return()=>clearTimeout(t);},[]);return(<div style={{position:"fixed",inset:0,zIndex:9999,background:"rgba(8,10,14,.98)",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:18,animation:"popIn .15s ease"}}><div style={{fontSize:80}}>🚫</div><div style={{fontSize:22,fontWeight:800,color:"#f85149"}}>Captura bloqueada</div><div style={{fontSize:14,color:"#7d8590",textAlign:"center",maxWidth:280,lineHeight:1.7}}>El contenido fue ocultado.<br/><strong style={{color:"#e6edf3"}}>{name}</strong> quedó registrado/a.</div><div style={{background:"rgba(248,81,73,.1)",border:"1px solid rgba(248,81,73,.3)",borderRadius:12,padding:"10px 24px",fontSize:12,color:"#f85149"}}>⚠️ Los demás participantes fueron notificados</div></div>);}

// ─── VPN Warning ───
function VPNWarning({info,onContinue,onLeave}){return(<div style={{position:"fixed",inset:0,zIndex:8500,background:"rgba(8,10,14,.96)",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:16,padding:24}}><div style={{fontSize:64}}>🕵️</div><div style={{fontSize:20,fontWeight:800,color:"#e3b341"}}>VPN / Proxy detectado</div><div style={{background:"rgba(227,179,65,.08)",border:"1px solid rgba(227,179,65,.25)",borderRadius:16,padding:20,maxWidth:340,textAlign:"center"}}>
  <p style={{fontSize:14,color:"#e6edf3",lineHeight:1.7}}>Tu conexión parece pasar por <strong style={{color:"#e3b341"}}>{info.type}</strong>.</p>
  <p style={{fontSize:12,color:"#7d8590",marginTop:8}}>IP: {info.ip} · {info.country}</p>
</div>
<p style={{fontSize:13,color:"#7d8590",textAlign:"center",maxWidth:300}}>La sala puede tener restricciones para conexiones anónimas. ¿Querés continuar de todas formas?</p>
<div style={{display:"flex",gap:12}}><button onClick={onLeave} style={{background:"none",border:"1.5px solid #f85149",borderRadius:12,padding:"10px 24px",color:"#f85149",cursor:"pointer",fontFamily:"'Outfit',sans-serif",fontWeight:600,fontSize:14}}>Salir</button><button onClick={onContinue} style={{background:"#e3b341",border:"none",borderRadius:12,padding:"10px 24px",color:"#0d1117",cursor:"pointer",fontFamily:"'Outfit',sans-serif",fontWeight:700,fontSize:14}}>Continuar igual</button></div>
</div>);}

// ─── CSS ───
const css=`
  @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap');
  *{box-sizing:border-box;margin:0;padding:0}
  :root{--deep:#0d1117;--panel:#161b22;--surface:#1c2330;--hover:#21293a;--b-in:#1e2d3d;--b-out:#1a4a7a;--ac:#2AABEE;--ac2:#1a80c0;--green:#3fb950;--red:#f85149;--gold:#e3b341;--text:#e6edf3;--muted:#7d8590;--border:#21293a;}
  body{font-family:'Outfit',sans-serif;background:var(--deep);color:var(--text);}
  ::-webkit-scrollbar{width:3px}::-webkit-scrollbar-thumb{background:#30363d;border-radius:4px}
  @keyframes fadeUp{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
  @keyframes popIn{from{opacity:0;transform:scale(.94)}to{opacity:1;transform:scale(1)}}
  @keyframes slideDown{from{opacity:0;transform:translateY(-12px)}to{opacity:1;transform:translateY(0)}}
  @keyframes pulse2{0%,100%{opacity:1}50%{opacity:.35}}
  @keyframes recPulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.5;transform:scale(.8)}}
  @keyframes shimmer{0%{opacity:.4}50%{opacity:.9}100%{opacity:.4}}
  .msg{animation:fadeUp .18s ease}.card{animation:popIn .22s ease}.rbar{animation:slideDown .15s ease}
  input,textarea{font-family:'Outfit',sans-serif;outline:none}textarea{resize:none}
  .btn-p{background:var(--ac);color:#fff;border:none;border-radius:12px;padding:12px 24px;font-size:15px;font-weight:600;cursor:pointer;font-family:'Outfit',sans-serif;transition:all .2s;width:100%}
  .btn-p:hover{background:var(--ac2);transform:translateY(-1px)}
  .inp{background:var(--surface);border:1.5px solid var(--border);border-radius:12px;padding:11px 16px;color:var(--text);font-size:15px;width:100%;transition:border-color .2s}
  .inp:focus{border-color:var(--ac)}.inp::placeholder{color:var(--muted)}
  .ico{background:none;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;border-radius:10px;padding:7px;transition:all .15s;color:var(--muted)}
  .ico:hover{background:var(--hover);color:var(--text)}
  .ebtn{background:none;border:none;cursor:pointer;font-size:18px;padding:4px 6px;border-radius:8px;transition:transform .12s;line-height:1}.ebtn:hover{transform:scale(1.35)}
  .rpill{display:inline-flex;align-items:center;gap:3px;background:var(--surface);border:1px solid var(--border);border-radius:20px;padding:2px 8px;cursor:pointer;font-size:13px;transition:all .15s;margin:2px 2px 0 0}.rpill:hover{border-color:var(--ac)}
  .ctry-card{background:var(--surface);border:1.5px solid var(--border);border-radius:12px;padding:10px 8px;cursor:pointer;text-align:center;transition:all .18s;display:flex;flex-direction:column;align-items:center;gap:4px}.ctry-card:hover{border-color:var(--ac);transform:translateY(-2px)}.ctry-card.sel{border-color:var(--ac);background:rgba(42,171,238,.12)}
  .shimmer{animation:shimmer 1.2s ease infinite}
  .tog{display:flex;align-items:center;gap:10;cursor:pointer;padding:4px 0}
  img{-webkit-user-drag:none}
`;

export default function App(){
  // ─ Screen & identity ─
  const[screen,setScreen]=useState("welcome");
  const[name,setName]=useState(""),  [nameErr,setNameErr]=useState("");
  const[country,setCountry]=useState(null), [cSearch,setCSearch]=useState("");
  // ─ Room ─
  const[room,setRoom]=useState(""), [roomPwd,setRoomPwd]=useState("");
  const[joinInput,setJoinInput]=useState(""), [joinErr,setJoinErr]=useState("");
  const[usePass,setUsePass]=useState(false), [createPwd,setCreatePwd]=useState("");
  const[allowlistInput,setAllowlistInput]=useState(""); // comma-separated usernames, empty=all
  const[allowlist,setAllowlist]=useState([]); // active allowlist for this session
  // ─ Security ─
  const[cryptoKey,setCryptoKey]=useState(null);
  const[pinEnabled,setPinEnabled]=useState(false), [pinValue,setPinValue]=useState("");
  const[pinLocked,setPinLocked]=useState(false), [pinAttempts,setPinAttempts]=useState(0);
  const[lockTimeout,setLockTimeout]=useState(300); // seconds
  const[incognito,setIncognito]=useState(false);
  const[vpnInfo,setVpnInfo]=useState(null), [showVPN,setShowVPN]=useState(false);
  const[showAlert,setShowAlert]=useState(false);
  // ─ Chat ─
  const[messages,setMessages]=useState([]);
  const[text,setText]=useState("");
  const[reactions,setReactions]=useState({});
  const[translations,setTranslations]=useState({});
  const[online,setOnline]=useState({});
  const[pinned,setPinned]=useState(null);
  const[destroyed,setDestroyed]=useState(new Set());
  const[sdDur,setSdDur]=useState(null), [showSdPicker,setShowSdPicker]=useState(false);
  const[recording,setRecording]=useState(false), [recTime,setRecTime]=useState(0);
  const[showPoll,setShowPoll]=useState(false), [pollQ,setPollQ]=useState(""), [pollOpts,setPollOpts]=useState(["",""]);
  const[hoverMsg,setHoverMsg]=useState(null), [showOrig,setShowOrig]=useState({});
  const[copied,setCopied]=useState(false), [connected,setConnected]=useState(false);
  const[imgErr,setImgErr]=useState(""), [typingUsers,setTypingUsers]=useState({});
  const[joinToasts,setJoinToasts]=useState([]);
  const[denied,setDenied]=useState(false);

  // ─ Refs ─
  const ttRef=useRef("0"), activeRef=useRef(false), endRef=useRef(null);
  const inputRef=useRef(null), fileRef=useRef(null);
  const nameRef=useRef(""), countryRef=useRef(null), channelRef=useRef("");
  const hoverTimer=useRef(null), transQueue=useRef([]), transRunning=useRef(false);
  const recorderRef=useRef(null), recChunks=useRef([]), recTimerRef=useRef(null);
  const typingTimer=useRef(null), lastAlertRef=useRef(0), lockTimer=useRef(null);
  const pubRef=useRef(null), cryptoKeyRef=useRef(null), pinRef=useRef("");
  const allowlistRef=useRef([]);

  useEffect(()=>{nameRef.current=name;},[name]);
  useEffect(()=>{countryRef.current=country;},[country]);
  useEffect(()=>{cryptoKeyRef.current=cryptoKey;},[cryptoKey]);
  useEffect(()=>{pinRef.current=pinValue;},[pinValue]);
  useEffect(()=>{allowlistRef.current=allowlist;},[allowlist]);
  useEffect(()=>{endRef.current?.scrollIntoView({behavior:"smooth"});},[messages]);

  // ── PIN inactivity lock ──
  const resetLockTimer=useCallback(()=>{
    if(!pinEnabled||pinLocked)return;
    clearTimeout(lockTimer.current);
    lockTimer.current=setTimeout(()=>{if(pinRef.current)setPinLocked(true);},lockTimeout*1000);
  },[pinEnabled,pinLocked,lockTimeout]);

  useEffect(()=>{
    if(screen!=="chat"||!pinEnabled)return;
    const evts=["mousedown","keydown","touchstart","scroll","mousemove"];
    evts.forEach(e=>document.addEventListener(e,resetLockTimer,{passive:true}));
    resetLockTimer();
    return()=>{evts.forEach(e=>document.removeEventListener(e,resetLockTimer));clearTimeout(lockTimer.current);};
  },[screen,pinEnabled,resetLockTimer]);

  // ── Screenshot protection ──
  useEffect(()=>{
    if(screen!=="chat")return;
    const trigger=()=>{const now=Date.now();if(now-lastAlertRef.current<6000)return;lastAlertRef.current=now;setShowAlert(true);if(pubRef.current)pubRef.current({id:uid(),type:"sys",text:`🚨 ${nameRef.current} intentó capturar la pantalla`,time:Date.now(),isAlert:true});};
    const onKey=e=>{const b=e.key==="PrintScreen"||(e.metaKey&&e.shiftKey&&["3","4","5","6"].includes(e.key))||(e.ctrlKey&&e.shiftKey&&(e.key==="S"||e.key==="s"))||(e.ctrlKey&&(e.key==="p"||e.key==="P"))||(e.metaKey&&(e.key==="p"||e.key==="P"));if(b){e.preventDefault();e.stopPropagation();trigger();}};
    const onKeyUp=e=>{if(e.key==="PrintScreen"){e.preventDefault();trigger();}};
    const onVis=()=>{if(document.visibilityState==="hidden"){trigger();if(incognito)setMessages([]);}};
    const onCtx=e=>{if(e.target.tagName==="IMG")e.preventDefault();};
    document.addEventListener("keydown",onKey,true);document.addEventListener("keyup",onKeyUp,true);
    document.addEventListener("visibilitychange",onVis);document.addEventListener("contextmenu",onCtx);
    return()=>{document.removeEventListener("keydown",onKey,true);document.removeEventListener("keyup",onKeyUp,true);document.removeEventListener("visibilitychange",onVis);document.removeEventListener("contextmenu",onCtx);};
  },[screen,incognito]);

  // ── Translation queue ──
  const processQueue=async()=>{if(transRunning.current)return;transRunning.current=true;while(transQueue.current.length>0){const{msg,toLangName}=transQueue.current.shift();try{const t=await callClaude(`Translate to ${toLangName}. Reply ONLY with the translation:\n\n${msg.text}`);setTranslations(p=>({...p,[msg.id]:{done:true,text:t,from:msg.langName,fromFlag:msg.flag}}));}catch{setTranslations(p=>({...p,[msg.id]:{done:true,text:msg.text,from:msg.langName,fromFlag:msg.flag,err:true}}));}await sleep(300);}transRunning.current=false;};
  const queueTrans=msg=>{const my=countryRef.current;if(!my||!msg.lang||msg.lang===my.lang||msg.type!=="msg")return;setTranslations(p=>({...p,[msg.id]:{done:false,from:msg.langName,fromFlag:msg.flag}}));transQueue.current.push({msg,toLangName:my.langName});processQueue();};

  // ── Subscribe ──
  useEffect(()=>{
    if(screen!=="chat"||!room)return;
    activeRef.current=true;ttRef.current="0";
    setConnected(false);setMessages([]);setReactions({});setOnline({});setTranslations({});setPinned(null);
    const ch=channelRef.current;

    const handle=async msg=>{
      if(!msg?.id)return;
      // Decrypt if needed
      if((msg.type==="msg")&&msg.enc&&cryptoKeyRef.current){
        const plain=await decryptText(cryptoKeyRef.current,msg.enc);
        if(plain===null){msg.text="[🔐 No se pudo descifrar]";msg.decryptFailed=true;}else msg.text=plain;
      }
      // Allowlist check
      if((msg.type==="msg"||msg.type==="img"||msg.type==="audio"||msg.type==="poll")&&msg.sender!==myUUID){
        const al=allowlistRef.current;
        if(al.length>0&&!al.map(u=>u.toLowerCase()).includes((msg.user||"").toLowerCase())){
          // Not on allowlist — show warning, skip
          setMessages(p=>[...p,{id:uid(),type:"sys",text:`🚫 Mensaje de ${msg.user} bloqueado (no está en la lista de permitidos)`,time:Date.now(),isAlert:true}]);
          return;
        }
      }
      if(msg.type==="msg"){setMessages(p=>{if(p.find(m=>m.id===msg.id))return p;if(msg.sender!==myUUID){playNotif();queueTrans(msg);}return[...p,msg];});}
      else if(msg.type==="img"||msg.type==="audio"){setMessages(p=>{if(p.find(m=>m.id===msg.id))return p;if(msg.sender!==myUUID)playNotif();return[...p,msg];});}
      else if(msg.type==="sys"){setMessages(p=>p.find(m=>m.id===msg.id)?p:[...p,msg]);}
      else if(msg.type==="poll"){setMessages(p=>p.find(m=>m.id===msg.id)?p:[...p,msg]);}
      else if(msg.type==="vote"){setMessages(p=>p.map(m=>{if(m.id!==msg.pollId)return m;const opts=m.options.map(o=>({...o,votes:o.votes.filter(u=>u!==msg.user)}));opts[msg.optIdx]={...opts[msg.optIdx],votes:[...opts[msg.optIdx].votes,msg.user]};return{...m,options:opts};}));}
      else if(msg.type==="reaction"){setReactions(p=>{const cur=p[msg.msgId]||{},users=cur[msg.emoji]||[];if(users.includes(msg.user))return p;return{...p,[msg.msgId]:{...cur,[msg.emoji]:[...users,msg.user]}};});}
      else if(msg.type==="pin"){setPinned(msg);setMessages(p=>p.find(m=>m.id===msg.id)?p:[...p,{id:msg.id,type:"sys",text:`📌 ${msg.pinner} fijó un mensaje`,time:msg.time}]);}
      else if(msg.type==="unpin"){setPinned(null);}
      else if(msg.type==="join"||msg.type==="heartbeat"){
        setOnline(p=>({...p,[msg.user]:{ts:Date.now(),flag:msg.flag||"",country:msg.countryName||""}}));
        if(msg.type==="join"&&msg.sender!==myUUID){
          playAlert();
          setJoinToasts(p=>[...p,{id:uid(),user:msg.user,flag:msg.flag||"",country:msg.countryName||""}]);
          setMessages(p=>p.find(m=>m.id===msg.id)?p:[...p,{id:msg.id,type:"sys",text:`${msg.flag||""} ${msg.user} se unió 👋`,time:msg.time}]);
        }
      }
      else if(msg.type==="leave"){setMessages(p=>p.find(m=>m.id===msg.id)?p:[...p,{id:msg.id,type:"sys",text:`${msg.flag||""} ${msg.user} salió`,time:msg.time}]);}
      else if(msg.type==="typing"){if(msg.sender!==myUUID)setTypingUsers(p=>({...p,[msg.user]:Date.now()}));}
      else if(msg.type==="denied"){if(msg.target===nameRef.current){setDenied(true);}}
    };

    const poll=async()=>{while(activeRef.current){try{const res=await fetch(`https://ps.pncdn.com/subscribe/${SUB_KEY}/${ch}/0/${ttRef.current}?uuid=${myUUID}`);if(!res.ok){await sleep(2000);continue;}const[msgs,tt]=await res.json();ttRef.current=tt;setConnected(true);for(const m of(msgs||[]))await handle(m);}catch{if(activeRef.current){setConnected(false);await sleep(3000);}}}};
    poll();
    return()=>{activeRef.current=false;};
  },[screen,room]);

  useEffect(()=>{if(screen!=="chat"||!room||!name||!country)return;const fn=()=>pub({id:uid(),type:"heartbeat",user:name,flag:country.flag,lang:country.lang,countryName:country.name,time:Date.now()});fn();const t=setInterval(fn,25000);return()=>clearInterval(t);},[screen,room,name,country]);
  useEffect(()=>{if(screen!=="chat")return;const t=setInterval(()=>{const now=Date.now();setOnline(p=>{const n={};for(const[u,d] of Object.entries(p))if(now-d.ts<65000)n[u]=d;return n;});setTypingUsers(p=>{const n={};for(const[u,ts] of Object.entries(p))if(now-ts<4000)n[u]=ts;return n;});},3000);return()=>clearInterval(t);},[screen]);

  const pub=async payload=>{try{await fetch(`https://ps.pncdn.com/publish/${PUB_KEY}/${SUB_KEY}/0/${channelRef.current}/0/${encodeURIComponent(JSON.stringify(payload))}`);}catch{}};
  useEffect(()=>{pubRef.current=pub;},[room]);

  const enterRoom=async(rId,pwd,al,pin,incog,lockT)=>{
    const ch=getCh(rId,pwd);channelRef.current=ch;
    // Derive crypto key if password set
    if(pwd){try{const k=await deriveKey(pwd,rId);setCryptoKey(k);}catch{}}
    // Set allowlist
    const parsed=al?al.split(",").map(u=>u.trim()).filter(Boolean):[];
    setAllowlist(parsed);
    // Set PIN
    if(pin){setPinValue(pin);setPinEnabled(true);}
    // Incognito
    setIncognito(!!incog);
    // Lock timeout
    if(lockT)setLockTimeout(lockT);
    // VPN check
    const vpn=await checkVPN();setVpnInfo(vpn);
    if(vpn.isVPN){setRoom(rId);setRoomPwd(pwd||"");setScreen("chat");setShowVPN(true);}
    else{setRoom(rId);setRoomPwd(pwd||"");setScreen("chat");}
    setTimeout(()=>pub({id:uid(),type:"join",user:nameRef.current,flag:countryRef.current?.flag||"",lang:countryRef.current?.lang||"es",langName:countryRef.current?.langName||"Español",countryName:countryRef.current?.name||"",sender:myUUID,time:Date.now()}),800);
  };

  const leaveRoom=()=>{
    pub({id:uid(),type:"leave",user:name,flag:country?.flag||"",time:Date.now()});
    setScreen("lobby");setMessages([]);setReactions({});setOnline({});setTranslations({});setPinned(null);setCryptoKey(null);setPinLocked(false);setPinEnabled(false);setPinValue("");setIncognito(false);setAllowlist([]);setDenied(false);
  };

  const send=async()=>{
    const t=text.trim();if(!t)return;setText("");
    let payload={id:uid(),type:"msg",user:name,color:getColor(name),text:t,time:Date.now(),sender:myUUID,lang:country?.lang||"es",langName:country?.langName||"Español",flag:country?.flag||""};
    if(sdDur)payload.selfDestruct=sdDur;
    // Encrypt if key
    if(cryptoKey){try{payload.enc=await encryptText(cryptoKey,t);}catch{}}
    if(!incognito)setMessages(p=>[...p,{...payload,encrypted:!!cryptoKey}]);
    await pub(payload);inputRef.current?.focus();
  };

  const sendImg=async file=>{setImgErr("");if(!file.type.startsWith("image/")){setImgErr("Solo imágenes");setTimeout(()=>setImgErr(""),3000);return;}try{const src=await compressImg(file);const msg={id:uid(),type:"img",user:name,color:getColor(name),src,time:Date.now(),sender:myUUID,flag:country?.flag||""};setMessages(p=>[...p,msg]);await pub(msg);}catch(e){setImgErr(e.message==="too_large"?"Imagen muy grande":"Error");setTimeout(()=>setImgErr(""),4000);}};

  const startRecording=async()=>{try{const stream=await navigator.mediaDevices.getUserMedia({audio:true});const mt=['audio/webm;codecs=opus','audio/webm','audio/ogg'].find(m=>MediaRecorder.isTypeSupported(m))||'';const mr=new MediaRecorder(stream,{mimeType:mt,audioBitsPerSecond:12000});recChunks.current=[];mr.ondataavailable=e=>{if(e.data.size>0)recChunks.current.push(e.data);};mr.onstop=()=>{stream.getTracks().forEach(t=>t.stop());const blob=new Blob(recChunks.current,{type:mr.mimeType||'audio/webm'});const r=new FileReader();r.onload=async e=>{const src=e.target.result;if(src.length>30000){setImgErr("Grabación muy larga");setTimeout(()=>setImgErr(""),4000);return;}const msg={id:uid(),type:"audio",user:name,color:getColor(name),src,duration:recTime,time:Date.now(),sender:myUUID,flag:country?.flag||""};setMessages(p=>[...p,msg]);await pub(msg);};r.readAsDataURL(blob);setRecording(false);setRecTime(0);clearInterval(recTimerRef.current);};mr.start(250);recorderRef.current=mr;setRecording(true);setRecTime(0);recTimerRef.current=setInterval(()=>setRecTime(v=>{if(v>=9){stopRecording();return v;}return v+1;}),1000);}catch{setImgErr("Micrófono no disponible");setTimeout(()=>setImgErr(""),3000);}};
  const stopRecording=()=>{if(recorderRef.current&&recorderRef.current.state!=="inactive")recorderRef.current.stop();clearInterval(recTimerRef.current);};

  const sendPoll=async()=>{const q=pollQ.trim();const opts=pollOpts.map(o=>o.trim()).filter(Boolean);if(!q||opts.length<2)return;const msg={id:uid(),type:"poll",user:name,question:q,options:opts.map(text=>({text,votes:[]})),time:Date.now(),sender:myUUID};setMessages(p=>[...p,msg]);await pub(msg);setShowPoll(false);setPollQ("");setPollOpts(["",""]);}; 
  const vote=async(pollId,optIdx)=>{setMessages(p=>p.map(m=>{if(m.id!==pollId)return m;const opts=m.options.map(o=>({...o,votes:o.votes.filter(u=>u!==name)}));opts[optIdx]={...opts[optIdx],votes:[...opts[optIdx].votes,name]};return{...m,options:opts};}));await pub({id:uid(),type:"vote",pollId,optIdx,user:name,time:Date.now()});};
  const addReaction=async(msgId,emoji)=>{setReactions(p=>{const cur=p[msgId]||{},users=cur[emoji]||[];if(users.includes(name))return p;return{...p,[msgId]:{...cur,[emoji]:[...users,name]}};});await pub({id:uid(),type:"reaction",msgId,emoji,user:name,time:Date.now()});setHoverMsg(null);};
  const pinMsg=async msg=>{const d={id:uid(),type:"pin",msgId:msg.id,text:msg.text||"[media]",user:msg.user,pinner:name,time:Date.now()};setPinned(d);await pub(d);setHoverMsg(null);};
  const unpin=async()=>{await pub({id:uid(),type:"unpin",time:Date.now()});setPinned(null);};
  const destroyMsg=msgId=>setDestroyed(p=>new Set([...p,msgId]));

  const handleKey=e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send();}};
  const fmtTime=ts=>new Date(ts).toLocaleTimeString("es",{hour:"2-digit",minute:"2-digit"});
  const isOwn=msg=>msg.sender===myUUID;
  const onMsgEnter=id=>{clearTimeout(hoverTimer.current);setHoverMsg(id);};
  const onMsgLeave=()=>{hoverTimer.current=setTimeout(()=>setHoverMsg(null),400);};
  const onPickEnter=()=>clearTimeout(hoverTimer.current);
  const onPickLeave=()=>{hoverTimer.current=setTimeout(()=>setHoverMsg(null),400);};
  const copyRoom=async()=>{try{await navigator.clipboard.writeText(roomPwd?`${room}#${roomPwd}`:room);}catch{}setCopied(true);setTimeout(()=>setCopied(false),2000);};
  const handleNameNext=()=>{if(name.trim().length<2){setNameErr("Mínimo 2 caracteres");return;}setNameErr("");setScreen("country");};

  const onlineList=Object.entries(online);
  const typingList=Object.keys(typingUsers);
  const filteredC=COUNTRIES.filter(c=>c.name.toLowerCase().includes(cSearch.toLowerCase())||c.langName.toLowerCase().includes(cSearch.toLowerCase()));

  // ── LOBBY FORM state ──
  const[lPin,setLPin]=useState(""), [lPinConfirm,setLPinConfirm]=useState("");
  const[lLock,setLLock]=useState(300);
  const[lIncog,setLIncog]=useState(false);
  const[lAllow,setLAllow]=useState("");
  const[lJoinCode,setLJoinCode]=useState(""), [lJoinPwd,setLJoinPwd]=useState("");

  // ── WELCOME ──
  if(screen==="welcome")return(<><style>{css}</style><div style={{minHeight:"100vh",background:"var(--deep)",display:"flex",alignItems:"center",justifyContent:"center",padding:20}}><div className="card" style={{background:"var(--panel)",border:"1px solid var(--border)",borderRadius:20,padding:40,width:"100%",maxWidth:380,boxShadow:"0 24px 64px rgba(0,0,0,.5)"}}><div style={{textAlign:"center",marginBottom:32}}><div style={{width:72,height:72,borderRadius:20,background:"linear-gradient(135deg,var(--ac),var(--ac2))",display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto 16px",fontSize:34,boxShadow:"0 8px 24px rgba(42,171,238,.3)"}}>💬</div><h1 style={{fontSize:26,fontWeight:700,letterSpacing:"-.5px"}}>PrivateChat</h1><p style={{color:"var(--muted)",fontSize:13,marginTop:6}}>E2E · AES-256 · PIN · VPN detect · Incógnito</p></div><div style={{display:"flex",flexDirection:"column",gap:14}}><div><label style={{fontSize:13,color:"var(--muted)",marginBottom:6,display:"block"}}>¿Cómo te llamás?</label><input className="inp" placeholder="Tu nombre o apodo" value={name} onChange={e=>{setName(e.target.value);setNameErr("");}} onKeyDown={e=>e.key==="Enter"&&handleNameNext()} maxLength={24} autoFocus/>{nameErr&&<p style={{color:"var(--red)",fontSize:12,marginTop:5}}>{nameErr}</p>}</div><button className="btn-p" onClick={handleNameNext}>Continuar →</button></div></div></div></>);

  // ── COUNTRY ──
  if(screen==="country")return(<><style>{css}</style><div style={{minHeight:"100vh",background:"var(--deep)",display:"flex",alignItems:"center",justifyContent:"center",padding:20}}><div className="card" style={{background:"var(--panel)",border:"1px solid var(--border)",borderRadius:20,padding:32,width:"100%",maxWidth:520,boxShadow:"0 24px 64px rgba(0,0,0,.5)"}}><div style={{display:"flex",alignItems:"center",gap:12,marginBottom:20}}><Avatar name={name} size={40} ring/><div><div style={{fontWeight:600,fontSize:15}}>{name}</div><div style={{color:"var(--muted)",fontSize:12}}>Paso 2 de 3</div></div></div><h2 style={{fontSize:18,fontWeight:700,marginBottom:4}}>🌍 ¿De qué país sos?</h2><p style={{color:"var(--muted)",fontSize:13,marginBottom:16}}>Tus mensajes se traducirán automáticamente.</p><input className="inp" placeholder="Buscar país..." value={cSearch} onChange={e=>setCSearch(e.target.value)} style={{marginBottom:14}}/><div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(88px,1fr))",gap:8,maxHeight:280,overflowY:"auto",paddingRight:4}}>{filteredC.map(c=>(<button key={c.code} className={`ctry-card${country?.code===c.code?" sel":""}`} onClick={()=>setCountry(c)}><span style={{fontSize:26}}>{c.flag}</span><span style={{fontSize:11,fontWeight:600}}>{c.name}</span><span style={{fontSize:10,color:"var(--muted)"}}>{c.langName}</span></button>))}</div>{country&&(<div style={{marginTop:14,padding:"12px 16px",background:"rgba(42,171,238,.1)",border:"1px solid rgba(42,171,238,.3)",borderRadius:12,display:"flex",alignItems:"center",gap:10}}><span style={{fontSize:28}}>{country.flag}</span><div><div style={{fontWeight:600,fontSize:14}}>{country.name}</div><div style={{color:"var(--muted)",fontSize:12}}>{country.langName}</div></div><button className="btn-p" onClick={()=>setScreen("lobby")} style={{marginLeft:"auto",width:"auto",padding:"8px 20px",fontSize:14}}>Listo →</button></div>)}<button onClick={()=>setScreen("welcome")} style={{background:"none",border:"none",color:"var(--muted)",cursor:"pointer",fontSize:13,fontFamily:"'Outfit',sans-serif",padding:"12px 0 0",display:"block",width:"100%",textAlign:"center"}}>← Volver</button></div></div></>);

  // ── LOBBY ──
  if(screen==="lobby"){
    const Tog=({checked,onChange,label,sub})=>(<label style={{display:"flex",alignItems:"flex-start",gap:10,cursor:"pointer",padding:"6px 0"}}><div style={{width:40,height:22,borderRadius:11,background:checked?"var(--ac)":"#21293a",position:"relative",flexShrink:0,marginTop:1,transition:"background .2s",cursor:"pointer"}} onClick={()=>onChange(!checked)}><div style={{width:18,height:18,borderRadius:"50%",background:"#fff",position:"absolute",top:2,left:checked?20:2,transition:"left .2s"}}/></div><div><div style={{fontSize:13,fontWeight:500}}>{label}</div>{sub&&<div style={{fontSize:11,color:"var(--muted)",marginTop:1}}>{sub}</div>}</div></label>);
    return(<><style>{css}</style><div style={{minHeight:"100vh",background:"var(--deep)",display:"flex",alignItems:"center",justifyContent:"center",padding:16}}><div className="card" style={{background:"var(--panel)",border:"1px solid var(--border)",borderRadius:20,padding:28,width:"100%",maxWidth:460,boxShadow:"0 24px 64px rgba(0,0,0,.5)",maxHeight:"95vh",overflowY:"auto"}}>
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:20,paddingBottom:16,borderBottom:"1px solid var(--border)"}}><Avatar name={name} size={42} ring/><div><div style={{fontWeight:600,fontSize:15}}>{name} {country?.flag}</div><div style={{color:"var(--muted)",fontSize:12}}>{country?.langName}</div></div></div>
      <div style={{display:"flex",flexDirection:"column",gap:12}}>
        {/* Create */}
        <div style={{background:"var(--surface)",borderRadius:14,padding:16,border:"1px solid var(--border)"}}>
          <div style={{fontSize:13,fontWeight:700,color:"var(--ac)",marginBottom:12}}>✨ Crear sala</div>
          <Tog checked={usePass} onChange={setUsePass} label="🔐 Contraseña" sub="Los mensajes se cifran con AES-256"/>
          {usePass&&<input className="inp" placeholder="Contraseña de cifrado" value={createPwd} onChange={e=>setCreatePwd(e.target.value)} type="password" style={{marginTop:8}}/>}
          <Tog checked={pinEnabled} onChange={setPinEnabled} label="🔢 Bloqueo por PIN" sub="Se bloquea después de inactividad"/>
          {pinEnabled&&<div style={{display:"flex",gap:8,marginTop:8}}>
            <input className="inp" placeholder="PIN (4 dígitos)" value={lPin} onChange={e=>setLPin(e.target.value.replace(/\D/g,"").slice(0,4))} type="password" maxLength={4}/>
            <select value={lLock} onChange={e=>setLLock(Number(e.target.value))} style={{background:"var(--surface)",border:"1.5px solid var(--border)",borderRadius:12,padding:"11px 12px",color:"var(--text)",fontSize:14,fontFamily:"'Outfit',sans-serif",cursor:"pointer"}}>{LOCK_OPTS.map(o=>(<option key={o.v} value={o.v}>⏱ {o.l}</option>))}</select>
          </div>}
          <Tog checked={lIncog} onChange={setLIncog} label="🕵️ Modo incógnito" sub="Sin historial, borra al salir o al cambiar pestaña"/>
          <div style={{marginTop:8}}>
            <label style={{fontSize:12,color:"var(--muted)",marginBottom:4,display:"block"}}>🚪 Usuarios permitidos <span style={{opacity:.6}}>(vacío = todos)</span></label>
            <input className="inp" placeholder="Alice, Bob, Charlie" value={lAllow} onChange={e=>setLAllow(e.target.value)} style={{fontSize:13}}/>
          </div>
          <button className="btn-p" onClick={()=>{if(pinEnabled&&lPin.length!==4){alert("PIN debe tener 4 dígitos");return;}enterRoom(roomCode(),usePass?createPwd:"",lAllow,pinEnabled?lPin:"",lIncog,lLock);}} style={{marginTop:14}}>Crear sala {usePass&&createPwd?"🔐":""}{pinEnabled?"🔢":""}{lIncog?"🕵️":""}</button>
        </div>
        {/* Join */}
        <div style={{background:"var(--surface)",borderRadius:14,padding:16,border:"1px solid var(--border)"}}>
          <div style={{fontSize:13,fontWeight:700,color:"var(--green)",marginBottom:10}}>🔗 Unirse a sala</div>
          <div style={{display:"flex",gap:8}}>
            <input className="inp" placeholder="CÓDIGO o CÓDIGO#contraseña" value={lJoinCode} onChange={e=>{setLJoinCode(e.target.value);setJoinErr("");}} onKeyDown={e=>e.key==="Enter"&&(()=>{const parts=lJoinCode.trim().split("#");const code=parts[0].toUpperCase();const pwd=parts[1]||lJoinPwd;if(code.length<4){setJoinErr("Código inválido");return;}enterRoom(code,pwd,"","",false,300);})()} maxLength={30} style={{letterSpacing:1,fontWeight:700}}/>
            <button onClick={()=>{const parts=lJoinCode.trim().split("#");const code=parts[0].toUpperCase();const pwd=parts[1]||lJoinPwd;if(code.length<4){setJoinErr("Código inválido");return;}enterRoom(code,pwd,"","",false,300);}} style={{background:"var(--green)",color:"#fff",border:"none",borderRadius:12,padding:"0 18px",fontSize:15,fontWeight:700,cursor:"pointer",fontFamily:"'Outfit',sans-serif",flexShrink:0}}>Entrar</button>
          </div>
          {joinErr&&<p style={{color:"var(--red)",fontSize:12,marginTop:6}}>{joinErr}</p>}
          <p style={{fontSize:11,color:"var(--muted)",marginTop:8}}>Si tiene contraseña: <strong>CODIGO#contraseña</strong></p>
        </div>
        <button onClick={()=>setScreen("country")} style={{background:"none",border:"none",color:"var(--muted)",cursor:"pointer",fontSize:13,fontFamily:"'Outfit',sans-serif",padding:6}}>← Cambiar país</button>
      </div>
    </div></div></>);
  }

  // ── CHAT ──
  return(<><style>{css}</style>
  <div style={{height:"100vh",display:"flex",flexDirection:"column",background:"var(--deep)",userSelect:"none"}}>
    <Watermark name={name}/>
    {showAlert&&<AlertOverlay name={name} onDone={()=>setShowAlert(false)}/>}
    {pinLocked&&<PinLock attempts={pinAttempts} onUnlock={entered=>{if(entered===pinRef.current){setPinLocked(false);setPinAttempts(0);resetLockTimer();return true;}else{setPinAttempts(p=>p+1);return false;}}}/>}
    {showVPN&&vpnInfo&&<VPNWarning info={vpnInfo} onContinue={()=>setShowVPN(false)} onLeave={()=>{leaveRoom();setShowVPN(false);}}/>}
    {denied&&<div style={{position:"fixed",inset:0,zIndex:8000,background:"rgba(8,10,14,.97)",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:16}}><div style={{fontSize:64}}>🚫</div><div style={{fontSize:20,fontWeight:700,color:"var(--red)"}}>Acceso denegado</div><p style={{color:"var(--muted)",fontSize:14}}>Tu usuario no está en la lista de permitidos de esta sala.</p><button className="btn-p" onClick={leaveRoom} style={{width:"auto",padding:"10px 28px",marginTop:8}}>Volver</button></div>}

    {/* Join toasts */}
    {joinToasts.slice(-1).map(t=>(<JoinToast key={t.id} user={t.user} flag={t.flag} country={t.country} onDone={()=>setJoinToasts(p=>p.filter(x=>x.id!==t.id))}/>))}

    {/* Header */}
    <div style={{background:"var(--panel)",borderBottom:"1px solid var(--border)",padding:"10px 14px",display:"flex",alignItems:"center",gap:8,flexShrink:0}}>
      <button className="ico" onClick={leaveRoom}><svg width="18" height="18" fill="none" viewBox="0 0 24 24"><path d="M19 12H5M5 12l7 7M5 12l7-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg></button>
      <div style={{width:36,height:36,borderRadius:10,background:"linear-gradient(135deg,var(--ac),var(--ac2))",display:"flex",alignItems:"center",justifyContent:"center",fontSize:17,flexShrink:0}}>💬</div>
      <div style={{flex:1,minWidth:0}}>
        <div style={{fontWeight:700,fontSize:14,display:"flex",alignItems:"center",gap:5,flexWrap:"wrap"}}>
          Sala {roomPwd&&<span title="AES-256 cifrado">🔐</span>}{pinEnabled&&<span title="PIN activo">🔢</span>}{incognito&&<span title="Incógnito">🕵️</span>}{allowlist.length>0&&<span title="Lista restringida">🚪</span>}<span title="Anti-capturas">🛡️</span>
          <div style={{width:6,height:6,borderRadius:"50%",background:connected?"var(--green)":"var(--red)",animation:connected?"none":"pulse2 1.5s infinite"}}/>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:4,marginTop:2}}>
          {onlineList.slice(0,5).map(([u,d],i)=>(<div key={u} title={u} style={{marginLeft:i>0?-5:0,zIndex:5-i}}><Avatar name={u} size={18} ring/></div>))}
          {onlineList.length>0&&<span style={{fontSize:10,color:"var(--muted)",marginLeft:4}}>{onlineList.length} online</span>}
          {incognito&&<span style={{fontSize:10,color:"var(--gold)",marginLeft:6}}>· SIN HISTORIAL</span>}
        </div>
      </div>
      <div style={{display:"flex",gap:5,alignItems:"center",flexShrink:0}}>
        <div style={{background:"var(--surface)",border:"1px solid var(--border)",borderRadius:16,padding:"3px 8px",fontSize:12,display:"flex",alignItems:"center",gap:4}}><span>{country?.flag}</span><span style={{color:"var(--muted)",fontSize:11}}>{country?.langName}</span></div>
        <button onClick={copyRoom} style={{background:copied?"rgba(63,185,80,.15)":"rgba(42,171,238,.1)",border:`1.5px solid ${copied?"var(--green)":"var(--ac)"}`,borderRadius:16,padding:"3px 10px",cursor:"pointer",display:"flex",alignItems:"center",gap:4,transition:"all .2s"}}>
          <span style={{fontWeight:800,fontSize:11,letterSpacing:2,color:copied?"var(--green)":"var(--ac)"}}>{room}{roomPwd?"🔐":""}</span>
          {copied?<svg width="11" height="11" fill="none" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7" stroke="#3fb950" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg>:<svg width="10" height="10" fill="none" viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2" stroke="#2AABEE" strokeWidth="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1" stroke="#2AABEE" strokeWidth="2"/></svg>}
        </button>
      </div>
    </div>

    {/* Pinned */}
    {pinned&&(<div style={{background:"rgba(227,179,65,.08)",borderBottom:"1px solid rgba(227,179,65,.2)",padding:"8px 14px",display:"flex",alignItems:"center",gap:8,flexShrink:0}}><span>📌</span><div style={{flex:1,fontSize:13,color:"var(--gold)",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}><strong>{pinned.user}:</strong> {pinned.text}</div><button onClick={unpin} style={{background:"none",border:"none",color:"var(--muted)",cursor:"pointer",fontSize:16}}>&times;</button></div>)}

    {/* Poll creator */}
    {showPoll&&(<div style={{background:"var(--panel)",borderBottom:"1px solid var(--border)",padding:"14px 16px",flexShrink:0}}><div style={{fontSize:13,fontWeight:700,marginBottom:10,display:"flex",justifyContent:"space-between"}}>📊 Nueva encuesta<button onClick={()=>setShowPoll(false)} style={{background:"none",border:"none",color:"var(--muted)",cursor:"pointer",fontSize:18}}>&times;</button></div><input className="inp" placeholder="¿Cuál es tu pregunta?" value={pollQ} onChange={e=>setPollQ(e.target.value)} style={{marginBottom:8}}/>{pollOpts.map((o,i)=>(<div key={i} style={{display:"flex",gap:6,marginBottom:6}}><input className="inp" placeholder={`Opción ${i+1}`} value={o} onChange={e=>{const n=[...pollOpts];n[i]=e.target.value;setPollOpts(n);}} style={{flex:1}}/>{i>=2&&<button onClick={()=>setPollOpts(p=>p.filter((_,j)=>j!==i))} style={{background:"none",border:"none",color:"var(--red)",cursor:"pointer",fontSize:18}}>&times;</button>}</div>))}<div style={{display:"flex",gap:8,marginTop:8}}>{pollOpts.length<5&&<button onClick={()=>setPollOpts(p=>[...p,""])} style={{background:"var(--surface)",border:"1px solid var(--border)",borderRadius:8,padding:"7px 14px",color:"var(--ac)",cursor:"pointer",fontSize:13,fontFamily:"'Outfit',sans-serif"}}>+ Opción</button>}<button onClick={sendPoll} className="btn-p" style={{flex:1,padding:"8px"}}>Publicar</button></div></div>)}

    {/* Messages */}
    <div style={{flex:1,overflowY:incognito?"hidden":"auto",padding:"12px 14px 8px",display:"flex",flexDirection:"column",gap:6}}>
      {messages.length===0&&(<div style={{textAlign:"center",padding:"36px 20px",color:"var(--muted)",fontSize:13}}><div style={{fontSize:40,marginBottom:12}}>🛡️</div><div style={{fontWeight:600,color:"var(--text)",marginBottom:6}}>{cryptoKey?"Sala cifrada AES-256":"Sala segura"}{incognito?" · Modo incógnito":""}</div><div>Código: <strong style={{color:"var(--ac)"}}>{room}{roomPwd?`#${roomPwd}`:""}</strong></div></div>)}

      {messages.map(msg=>{
        if(msg.type==="sys")return(<div key={msg.id} style={{textAlign:"center",padding:"3px 0"}}><span style={{background:msg.isAlert?"rgba(248,81,73,.1)":"rgba(42,171,238,.07)",color:msg.isAlert?"var(--red)":"var(--muted)",fontSize:12,padding:"3px 12px",borderRadius:20}}>{msg.text}</span></div>);
        if(destroyed.has(msg.id))return null;
        const own=isOwn(msg),msgR=reactions[msg.id]||{},hasR=Object.values(msgR).some(u=>u.length>0);
        const trans=translations[msg.id],needsTrans=!own&&msg.lang&&msg.lang!==country?.lang&&msg.type==="msg";
        const showingOrig=showOrig[msg.id],displayText=needsTrans&&trans?.done&&!showingOrig?trans.text:msg.text;
        return(<div key={msg.id} className="msg" style={{display:"flex",justifyContent:own?"flex-end":"flex-start",alignItems:"flex-end",gap:6,position:"relative"}} onMouseEnter={()=>onMsgEnter(msg.id)} onMouseLeave={onMsgLeave}>
          {!own&&<Avatar name={msg.user||"?"} size={28}/>}
          <div style={{maxWidth:"72%"}}>
            {!own&&<div style={{fontSize:11,fontWeight:600,color:msg.color||"var(--ac)",marginBottom:2,paddingLeft:4,display:"flex",alignItems:"center",gap:3}}><span>{msg.flag}</span>{msg.user}{msg.decryptFailed&&<span style={{color:"var(--red)",fontSize:10}}>🔐</span>}</div>}
            {hoverMsg===msg.id&&(<div className="rbar" onMouseEnter={onPickEnter} onMouseLeave={onPickLeave} style={{position:"absolute",top:-42,[own?"right":"left"]:own?0:34,background:"var(--surface)",border:"1px solid var(--border)",borderRadius:24,padding:"5px 8px",display:"flex",gap:2,boxShadow:"0 6px 20px rgba(0,0,0,.5)",zIndex:10,alignItems:"center"}}>{EMOJIS.map(e=>(<button key={e} className="ebtn" onClick={()=>addReaction(msg.id,e)}>{e}</button>))}<div style={{width:1,height:20,background:"var(--border)",margin:"0 4px"}}/><button className="ebtn" title="Fijar" onClick={()=>pinMsg(msg)} style={{fontSize:14}}>📌</button></div>)}
            {msg.type==="poll"?<div style={{background:own?"var(--b-out)":"var(--b-in)",borderRadius:own?"18px 18px 4px 18px":"18px 18px 18px 4px",padding:"12px 14px"}}><PollCard msg={msg} myName={name} onVote={vote}/></div>
            :msg.type==="img"?<img src={msg.src} alt="img" style={{maxWidth:210,maxHeight:210,borderRadius:own?"14px 14px 4px 14px":"14px 14px 14px 4px",display:"block",border:"1px solid var(--border)",pointerEvents:"none"}}/>
            :msg.type==="audio"?<div style={{background:own?"var(--b-out)":"var(--b-in)",borderRadius:own?"18px 18px 4px 18px":"18px 18px 18px 4px",padding:"8px 12px"}}><AudioPlayer src={msg.src} duration={msg.duration}/></div>
            :<div style={{background:own?"var(--b-out)":"var(--b-in)",borderRadius:own?"18px 18px 4px 18px":"18px 18px 18px 4px",padding:"9px 13px",fontSize:14,lineHeight:1.5,wordBreak:"break-word"}}>{needsTrans&&!trans?.done?<span className="shimmer" style={{color:"var(--muted)",fontSize:13}}>🌐 Traduciendo...</span>:displayText}{own&&cryptoKey&&<span style={{fontSize:10,color:"rgba(42,171,238,.5)",marginLeft:6}}>🔐</span>}</div>}
            {needsTrans&&trans?.done&&(<div style={{display:"flex",alignItems:"center",gap:5,marginTop:2,paddingLeft:4}}><span style={{fontSize:10,color:"var(--muted)"}}>{trans.err?"⚠️":`🌐 ${trans.fromFlag}→${country?.flag}`}</span><button onClick={()=>setShowOrig(p=>({...p,[msg.id]:!p[msg.id]}))} style={{background:"none",border:"none",color:"var(--ac)",fontSize:10,cursor:"pointer",fontFamily:"'Outfit',sans-serif",padding:0,textDecoration:"underline"}}>{showingOrig?"Ver traducción":"Ver original"}</button></div>)}
            {msg.selfDestruct&&!destroyed.has(msg.id)&&(<div style={{marginTop:3,paddingLeft:4}}><CountDown duration={msg.selfDestruct} onEnd={()=>destroyMsg(msg.id)}/></div>)}
            {hasR&&(<div style={{display:"flex",flexWrap:"wrap",marginTop:3,justifyContent:own?"flex-end":"flex-start"}}>{Object.entries(msgR).filter(([,u])=>u.length>0).map(([emoji,users])=>(<button key={emoji} className="rpill" onClick={()=>addReaction(msg.id,emoji)} title={users.join(", ")} style={{borderColor:users.includes(name)?"var(--ac)":"var(--border)",background:users.includes(name)?"rgba(42,171,238,.12)":"var(--surface)"}}>{emoji}<span style={{color:"var(--muted)",fontSize:12,marginLeft:2}}>{users.length}</span></button>))}</div>)}
            <div style={{fontSize:10,color:"var(--muted)",marginTop:2,textAlign:own?"right":"left",paddingLeft:own?0:3,paddingRight:own?3:0,display:"flex",justifyContent:own?"flex-end":"flex-start",alignItems:"center",gap:3}}>{fmtTime(msg.time)}{own&&<svg width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M1.5 12.5L7 18l4-4m3-7l-7 7M20 6l-4 4" stroke="#2AABEE" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>}</div>
          </div>
          {own&&<Avatar name={name} size={28}/>}
        </div>);
      })}
      {typingList.length>0&&(<div style={{display:"flex",alignItems:"center",gap:6,paddingLeft:36}}><div style={{background:"var(--b-in)",borderRadius:"18px 18px 18px 4px",padding:"8px 12px",display:"flex",gap:4,alignItems:"center"}}>{[0,1,2].map(i=>(<div key={i} style={{width:6,height:6,borderRadius:"50%",background:"var(--muted)",animation:"pulse2 1.2s ease infinite",animationDelay:`${i*.2}s`}}/>))}</div><span style={{fontSize:11,color:"var(--muted)"}}>{typingList.join(", ")}...</span></div>)}
      {imgErr&&(<div style={{textAlign:"center"}}><span style={{background:"rgba(248,81,73,.1)",color:"var(--red)",fontSize:12,padding:"5px 14px",borderRadius:20}}>{imgErr}</span></div>)}
      <div ref={endRef}/>
    </div>

    {/* SD picker */}
    {showSdPicker&&(<div style={{background:"var(--surface)",borderTop:"1px solid var(--border)",padding:"10px 14px",display:"flex",gap:8,alignItems:"center",flexShrink:0}}><span style={{fontSize:12,color:"var(--muted)"}}>💨 Autodestruir:</span>{SD_OPTS.map(o=>(<button key={o.v} onClick={()=>{setSdDur(sdDur===o.v?null:o.v);setShowSdPicker(false);}} style={{background:sdDur===o.v?"rgba(248,81,73,.2)":"var(--hover)",border:`1px solid ${sdDur===o.v?"var(--red)":"var(--border)"}`,borderRadius:8,padding:"5px 10px",color:sdDur===o.v?"var(--red)":"var(--text)",cursor:"pointer",fontSize:12,fontFamily:"'Outfit',sans-serif"}}>{o.l}</button>))}{sdDur&&<button onClick={()=>{setSdDur(null);setShowSdPicker(false);}} style={{background:"none",border:"none",color:"var(--muted)",cursor:"pointer",fontSize:11,fontFamily:"'Outfit',sans-serif",marginLeft:"auto"}}>Desactivar</button>}</div>)}

    {/* Input */}
    <div style={{background:"var(--panel)",borderTop:"1px solid var(--border)",padding:"10px 14px",flexShrink:0}}>
      {recording&&(<div style={{display:"flex",alignItems:"center",gap:10,padding:"6px 12px",background:"rgba(248,81,73,.1)",borderRadius:12,marginBottom:8,border:"1px solid rgba(248,81,73,.3)"}}><div style={{width:10,height:10,borderRadius:"50%",background:"var(--red)",animation:"recPulse 1s ease infinite"}}/><span style={{fontSize:13,color:"var(--red)",fontWeight:600}}>Grabando... {recTime}s / 10s</span><button onClick={stopRecording} style={{marginLeft:"auto",background:"var(--red)",color:"#fff",border:"none",borderRadius:8,padding:"4px 12px",fontSize:12,cursor:"pointer",fontFamily:"'Outfit',sans-serif",fontWeight:600}}>Enviar</button></div>)}
      <div style={{display:"flex",alignItems:"flex-end",gap:6}}>
        <input ref={fileRef} type="file" accept="image/*" style={{display:"none"}} onChange={e=>{if(e.target.files[0])sendImg(e.target.files[0]);e.target.value="";}}/>
        <button className="ico" onClick={()=>fileRef.current.click()} style={{width:36,height:36,flexShrink:0}}><svg width="18" height="18" fill="none" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="3" stroke="currentColor" strokeWidth="1.8"/><circle cx="8.5" cy="8.5" r="1.5" fill="currentColor"/><path d="M21 15l-5-5L5 21" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg></button>
        <button className="ico" onClick={recording?stopRecording:startRecording} style={{width:36,height:36,flexShrink:0,background:recording?"rgba(248,81,73,.15)":"none",color:recording?"var(--red)":"var(--muted)"}}><svg width="18" height="18" fill="none" viewBox="0 0 24 24"><rect x="9" y="2" width="6" height="12" rx="3" stroke="currentColor" strokeWidth="1.8"/><path d="M5 10a7 7 0 0014 0M12 19v3M9 22h6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></svg></button>
        <button className="ico" onClick={()=>setShowPoll(v=>!v)} style={{width:36,height:36,flexShrink:0,background:showPoll?"rgba(42,171,238,.15)":"none",color:showPoll?"var(--ac)":"var(--muted)"}}><svg width="18" height="18" fill="none" viewBox="0 0 24 24"><rect x="3" y="12" width="4" height="9" rx="1" stroke="currentColor" strokeWidth="1.8"/><rect x="10" y="7" width="4" height="14" rx="1" stroke="currentColor" strokeWidth="1.8"/><rect x="17" y="3" width="4" height="18" rx="1" stroke="currentColor" strokeWidth="1.8"/></svg></button>
        <button className="ico" onClick={()=>setShowSdPicker(v=>!v)} style={{width:36,height:36,flexShrink:0,background:sdDur?"rgba(248,81,73,.15)":"none",color:sdDur?"var(--red)":"var(--muted)"}}><svg width="18" height="18" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.8"/><path d="M12 7v5l3 3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg></button>
        <div style={{flex:1,background:"var(--surface)",borderRadius:22,padding:"7px 14px",border:`1.5px solid ${sdDur?"rgba(248,81,73,.5)":cryptoKey?"rgba(42,171,238,.4)":"var(--border)"}`,transition:"border-color .2s",userSelect:"text"}}>
          <textarea ref={inputRef} value={text} onChange={e=>{setText(e.target.value);if(pubRef.current)pubRef.current({id:uid(),type:"typing",user:name,sender:myUUID,time:Date.now()});}} onKeyDown={handleKey}
            placeholder={cryptoKey?"🔐 Mensaje cifrado AES-256...":sdDur?`💨 Temporal (${SD_OPTS.find(o=>o.v===sdDur)?.l})...`:`Escribí en ${country?.langName||"tu idioma"}...`}
            rows={1} style={{flex:1,background:"none",border:"none",color:"var(--text)",fontSize:14,lineHeight:1.5,width:"100%",maxHeight:90,overflowY:"auto"}} onInput={e=>{e.target.style.height="auto";e.target.style.height=e.target.scrollHeight+"px";}}/>
        </div>
        <button onClick={send} disabled={!text.trim()} style={{width:40,height:40,borderRadius:"50%",border:"none",background:text.trim()?(sdDur?"var(--red)":cryptoKey?"#8b5cf6":"var(--ac)"):"var(--surface)",display:"flex",alignItems:"center",justifyContent:"center",cursor:text.trim()?"pointer":"not-allowed",flexShrink:0,transition:"all .2s",opacity:text.trim()?1:.5}}><svg width="17" height="17" viewBox="0 0 24 24" fill="none"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg></button>
      </div>
    </div>
  </div></>);
}
